import React from 'react';
import UploadForm from './UploadForm'

const Admin = () => {
  return (
    <div className="title">
      <h2>This Is Admin</h2>
      <UploadForm />
    </div>
  )
}

export default Admin;